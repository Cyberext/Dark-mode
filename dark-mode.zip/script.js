// Dark Mode Toggle with localStorage Persistence
document.addEventListener('DOMContentLoaded', function() {
  
  const themeToggle = document.getElementById('themeToggle');
  const themeLabel = document.getElementById('themeLabel');
  const html = document.documentElement;
  
  // Check for saved theme preference or default to light mode
  const currentTheme = localStorage.getItem('theme') || 'light';
  
  // Apply the saved theme on page load
  html.setAttribute('data-theme', currentTheme);
  updateThemeLabel(currentTheme);
  
  // Theme toggle click handler
  themeToggle.addEventListener('click', function() {
    const currentTheme = html.getAttribute('data-theme');
    const newTheme = currentTheme === 'light' ? 'dark' : 'light';
    
    // Apply new theme
    html.setAttribute('data-theme', newTheme);
    
    // Save to localStorage
    localStorage.setItem('theme', newTheme);
    
    // Update label
    updateThemeLabel(newTheme);
    
    // Add animation class
    themeToggle.classList.add('toggling');
    setTimeout(() => {
      themeToggle.classList.remove('toggling');
    }, 300);
  });
  
  // Update theme label text
  function updateThemeLabel(theme) {
    themeLabel.textContent = theme === 'light' ? 'Dark Mode' : 'Light Mode';
  }
  
  // Smooth scroll for navigation links
  const navLinks = document.querySelectorAll('.nav-link');
  navLinks.forEach(link => {
    link.addEventListener('click', function(e) {
      e.preventDefault();
      const targetId = this.getAttribute('href').substring(1);
      const targetSection = document.getElementById(targetId);
      
      if (targetSection) {
        targetSection.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
      }
    });
  });
  
  // Newsletter form submission
  const newsletterForm = document.querySelector('.newsletter-form');
  newsletterForm.addEventListener('submit', function(e) {
    e.preventDefault();
    const emailInput = this.querySelector('.newsletter-input');
    const email = emailInput.value.trim();
    
    if (email) {
      // Simulate subscription
      alert(`Thank you for subscribing with ${email}!`);
      emailInput.value = '';
    }
  });
  
  // Add hover effect to article cards
  const articleCards = document.querySelectorAll('.article-card');
  articleCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
      this.style.transform = 'translateY(-8px)';
    });
    
    card.addEventListener('mouseleave', function() {
      this.style.transform = 'translateY(0)';
    });
  });
  
  // Add hover effect to category cards
  const categoryCards = document.querySelectorAll('.category-card');
  categoryCards.forEach(card => {
    card.addEventListener('mouseenter', function() {
      this.style.transform = 'translateY(-8px)';
    });
    
    card.addEventListener('mouseleave', function() {
      this.style.transform = 'translateY(0)';
    });
  });
  
  // Keyboard shortcut for theme toggle (Ctrl/Cmd + Shift + D)
  document.addEventListener('keydown', function(e) {
    if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === 'D') {
      e.preventDefault();
      themeToggle.click();
    }
  });
  
  // Log theme information
  console.log('🎨 Dark Mode Toggle - Initialized');
  console.log('Current Theme:', currentTheme);
  console.log('Theme saved in localStorage');
  console.log('Keyboard shortcut: Ctrl/Cmd + Shift + D');
  console.log('Developer: Rogen Tonderai Bharani');
});